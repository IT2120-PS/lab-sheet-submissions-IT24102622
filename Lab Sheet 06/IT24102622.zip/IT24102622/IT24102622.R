setwd("C:\\Users\\User\\Desktop\\IT24102622")

##Part 01

#Q(i)
#Binomial Distribution
#Here, random variable X has binomial distribution with n=50 and p=0.85

#Q(ii)
dbinom(47,50,0.85)

##Part 02

#Q(i)
#In here the random variable is X which is the number of customer calls recived in one hour.
#X = No of nustomer calls recived in one hour.

#Q(ii)
#Here randomvariable X has poission distribution with lambda = 12

#Q(iii)
dpois(15,12)